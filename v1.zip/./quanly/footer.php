  <footer class="py-3 my-4">
    <p class="text-center text-muted">CÔNG TY CỔ PHẦN PHÁT TRIỂN THỂ THAO ĐIỆN TỬ VIỆT NAM<br/>Giấy CNĐKKD số 0103959912, cấp lần đầu ngày 09/06/2009 | Cơ quan cấp: Phòng Đăng ký kinh doanh- Sở Kế hoạch và đầu tư TP Hà Nội<br/>Địa chỉ trụ sở chính: Tầng 29, Tòa nhà Trung tâm Lotte Hà Nội, số 54 đường Liễu Giai, Phường Cống Vị, Quận Ba Đình, TP Hà Nội, Việt Nam</p>
  </footer>
  <?php
  /*
************************************************
*                                              *
* MÃ NGUỒN ĐƯỢC CUNG CẤP BỞI TUANORI           *
* LIÊN HỆ QUA ZALO : 0812.665.005              *
* FACEBOOK : FB.COM/PHAMHOANGTUAN.YTB          *
* CODE BỞI TUẤN ORI IT                         *
* tuanori: view source cái thằng cha mày       *
*                                              *
************************************************ */
?>