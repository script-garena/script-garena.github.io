<html lang="vi"><head>
<!--
************************************************
*                                              *
* MÃ NGUỒN ĐƯỢC CUNG CẤP BỞI TUANORI           *
* LIÊN HỆ QUA ZALO : 0812.665.005              *
* FACEBOOK : FB.COM/PHAMHOANGTUAN.YTB          *
* CODE BỞI TUẤN ORI IT                         *
* tuanori: view source cái thằng cha mày       *
*                                              *
************************************************ -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<title>NẠP KIM CƯƠNG X5 GIÁ RẺ , GIAO DỊCH NHANH CHÓNG - TUANORI</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">


    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">


    <style>
    @import url("https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css");
        body {
    font: 14px arial,Microsoft JhengHei,\5FAE\8EDF\6B63\9ED1\9AD4,sans-serif;
    background: #fafafa;
    color: #202325;
    line-height: 1.5em;
}

nav.navbar.navbar-expand-lg.navbar-light.bg-light {
    background: #fff;
    box-sizing: border-box;
    margin: auto;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    border-bottom: 1px solid #ececec;
}
@media screen and (min-width: 800px) {
   nav.navbar.navbar-expand-lg.navbar-light.bg-light {
       padding: 5px 0;
    padding: 0 30px;
   }
}
.oxVbmPqVSkCVx79GnnLc7{width:100%;color:#202325;background:transparent;padding:8px 10px;border:1px solid #c6c6c6;border-radius:2px;text-align:left;display:block;-webkit-appearance:none;-moz-appearance:none;appearance:none;box-sizing:border-box;height:34px;-webkit-transition:border-color .3s,background-color .3s;transition:border-color .3s,background-color .3s}.oxVbmPqVSkCVx79GnnLc7::-webkit-input-placeholder{color:#676e76;color:hsla(212,7%,43%,.2)}.oxVbmPqVSkCVx79GnnLc7::-moz-placeholder{color:#676e76;color:hsla(212,7%,43%,.2);opacity:1}.oxVbmPqVSkCVx79GnnLc7:-ms-input-placeholder{color:#676e76;color:hsla(212,7%,43%,.2)}.oxVbmPqVSkCVx79GnnLc7:focus{border-color:#93939d}._2MQE1PGgPapWeDj8hUugWh{border-color:#d43831;background:#2b2b2e}
._3duKww4d68rWsj1YAVEbYt,.Sva6wwZSMctLulz_i_wEK ._2_Z5k48bD2qEQak-stRM7k{display:block;background:#d43831;color:#fff;border:none;width:100%;padding:10px 0;border-radius:3px;cursor:pointer;-webkit-transition:opacity .3s,background-color .3s;transition:opacity .3s,background-color .3s}._3duKww4d68rWsj1YAVEbYt:hover,.Sva6wwZSMctLulz_i_wEK ._2_Z5k48bD2qEQak-stRM7k:hover{background:#ef4b44}._3duKww4d68rWsj1YAVEbYt:active,.Sva6wwZSMctLulz_i_wEK ._2_Z5k48bD2qEQak-stRM7k:active{background:#a32924}._3duKww4d68rWsj1YAVEbYt:disabled,.Sva6wwZSMctLulz_i_wEK ._2_Z5k48bD2qEQak-stRM7k:disabled{opacity:.4;cursor:default}._3duKww4d68rWsj1YAVEbYt:disabled:hover,.Sva6wwZSMctLulz_i_wEK ._2_Z5k48bD2qEQak-stRM7k:disabled:hover{background:#d43831}
._3sYGlvN9b3AEZixLIfPEyv{color:#d43831;font-size:12px;margin:6px 0}
._3854NWI3hCrEquo01B8uB6, .dpr9T5rFL9edf2qPmAUyn {
    -webkit-flex-shrink: 0;
    -ms-flex-negative: 0;
    flex-shrink: 0;
}
.dpr9T5rFL9edf2qPmAUyn {
    width: 20px;
    height: 20px;
    margin: 0 8px 0 0;
}
._1j8kr6gdyocMniz8cNt_4z {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
}
._2UFlTfk9EmoZAo0ZXXVu2W {
    height: 24px;
    margin-right: 12px;
}
.xredk3DIbsOZHLQIgFAc5 {
    -webkit-box-flex: 0;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    margin: 0 10px 0 0;
}
.NAZifq9Yh9lpBiFhRgrDb {
    content: "";
    height: 1px;
    background-color: #ececec;
    -webkit-box-flex: 1;
    -webkit-flex: 1 1 auto;
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
}
._1bkv69haktLSa_dMeFyH7v {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    cursor: pointer;
    height: 24px;
    padding-left: 5px;
    padding-right: 5px;
    font-size: 12px;
    line-height: 12px;
    border-radius: 2px;
    border: 1px solid #acacae;
}
._1vq6_wmXgG2UYKxS9lmTpK {
    -webkit-box-flex: 0;
        text-decoration: none;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    color:#000;
    margin: 0 0 0 10px;
}
._1MRnh-Mn95TAy7cSnhP0Rn {
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA4ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo3NGM4ZmZlNi0wYjlmLTRmZDQtOGRiMy0xMWNhZWE5ZjMzZjMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NkEzMzAyN0E3RDAwMTFFOEIwQUU5QkI3RjA5Q0M4QzYiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NkEzMzAyNzk3RDAwMTFFOEIwQUU5QkI3RjA5Q0M4QzYiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo2MGY3NmM1MS00MDljLTQ1YWMtOWEzZi0xM2UxZjk0MTY0ZjQiIHN0UmVmOmRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo0OTk5ZDc3MS1iOTM5LWNmNDYtYjIxYS00YTQyODgwMmY2ZDYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz49YyW2AAACH0lEQVR42qyWQUgUURjHZ7eEsiUJhD14Ck8SFCjKuoqCt+jQiiJsl8IgJfOQ1mEFDYxcqsvWMSipQySuthQhXuxg1OY1O3gIhSjxIEEsFWyr/b74BmaX3Z03TR/8+N68mfn+77157/smkE4vWpXsZjIZxvVCO5yEevgN3+AjZCEzmUh8qRQjUE6AwA24+xCRZ6zqtgcvYQahz6U3g2WCH8DtQtgguB3jLLzm3X5XAUZRgF80n8I+bMA4dEAjHIcoXIU3jldr4R4il12XyDGbw4j9rDZ8nhGx2ypu2wjvPXcVMDVEjuIe6czEvkM3IjtBvenLCCQBB+GTdknMqb8zONXSmsHH3ZbCcCZtsm31UrZzRD6ydD7m5qH/MJM13Fu9PAgxexd1wgNEaiz/Nu9oR2WJvjo6XsGwbFXDJbmBG3I7JE47Ayk9bCY2DU+8CIj1yb5GJGCw5nIQEzDnRUDsnI7OMhS5Bi+8CIhdZBYThiLyzUZh2YuA2BVExgxF8rhLsFoq0AV5R995aHLw0MM5kDgX4F1RsmOUKdoD2rcJp/X4/+uJDuGeQbO9RHchp21Jx7M8VOfjROd0o6wHtUNK3nXN/5aWyCVNxX4SYLwoXRNQ1u9WSSWTorIA72Fbv1tYU/MR+ECwrHFNRiSGuwMhw8FK1uwoV48rlUxJtz2adgt+M59byZS/i5j+XZyAY/qd5KdgC35IqmdQK5Vi/BFgAJD1tLCpIpOJAAAAAElFTkSuQmCC);
    background-size: 100% 100%;
}

._1NsBtln0wVDA9d7SzMS4dG {
    width: 12px;
    height: 12px;
    margin-right: 5px;
}
._2LsywqJqKlvqc4GK5oYU3q {
    cursor: pointer;
}
._2_k9uzvvbrebWqOyOw7-ci {
    display: inline-block;
    vertical-align: middle;
    height: 20px;
    margin: 0 5px 0 0;
}
tr {
    text-align: center;
}
            .loading {
                background-color: #000000c4;
                top: 0;
                left: 0;
                position: fixed;
                width: 100%;
                height: 100%;
                z-index: 9998;
                display: none;
            }
            .lds-hourglass {
              display: inline-block;
              position: fixed;
              width: 64px;
              height: 64px;
              z-index: 9999;
              top: 45%;
              left: calc(50% - 32px);
            }
            .lds-hourglass:after {
              content: " ";
              display: block;
              border-radius: 50%;
              width: 0;
              height: 0;
              margin: 6px;
              box-sizing: border-box;
              border: 26px solid #fff;
              border-color: #fff transparent #fff transparent;
              animation: lds-hourglass 1.2s infinite;
            }
            @keyframes lds-hourglass {
              0% {
                transform: rotate(0);
                animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
              }
              50% {
                transform: rotate(900deg);
                animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
              }
              100% {
                transform: rotate(1800deg);
              }
            }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  </head>