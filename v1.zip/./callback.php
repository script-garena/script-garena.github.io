<?php

if(isset($_GET)){
    
	   $trans_id = $_GET['request_id'];
	   $code = $_GET['status'];
	   $serial = $_GET['serial'];
	   $value = $_GET['value'];
		   
		if($code =="hoantat") {

			$myfile = fopen("thedung.txt", "a");
			$txt = $_GET['status']."|".$_GET['serial']."|".$_GET['message']."|".number_format($_GET['value'])."|".$_GET['request_id']."\n";
			fwrite($myfile, $txt);
			fclose($myfile);

		} else {

			$myfile = fopen("thesai.txt", "a");
			$txt = $_GET['status']."|".$_GET['serial']."|".$_GET['message']."|".number_format($_GET['value'])."|".$_GET['request_id']."\n";
			fwrite($myfile, $txt);
			fclose($myfile);
		}
	}
?>