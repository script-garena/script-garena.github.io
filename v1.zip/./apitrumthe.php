<?php
$apikey = "2XuzsW6rTVgEPGFqMynDHOt8wc5aLBlI"; //API BÊN TRUMTHEVIP.TK
$linkcallback = "https://shopnapkc.net/callback.php"; // thay link web để nhận callback
$linkapi = "https://trumthevip.tk"; // KHÔNG THAY ĐỔI - ĐÂY LÀ LINK API

