<?php
$ApiKey = "l6j2rYqiRPuQ1FZyBWtET3hsOdA7fHUx"; //API BÊN TRUMTHEVIP.TK
$callback_url = "https://shopkc.net/callback.php"; 

